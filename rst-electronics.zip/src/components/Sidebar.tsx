import React from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Boxes,
  Wrench,
  Cctv,
  Truck,
  Zap,
  PhoneCall,
  Receipt,
  Landmark,
  FileText,
  RotateCcw,
  PackageCheck,
  Scale,
  CalendarRange,
  Crown,
  Sparkles,
  Lock,
  Unlock,
  AlertTriangle,
  ChevronRight,
  ShieldCheck,
  ArrowRightLeft,
  ShieldAlert,
  Users,
} from 'lucide-react';
import { LanguageCode, User } from '../types';
import { TRANSLATIONS } from '../utils/i18n';

export type NavigationTab =
  | 'dashboard'
  | 'pos'
  | 'inventory'
  | 'customers'
  | 'branchTransfer'
  | 'repairs'
  | 'pendingBottlenecks'
  | 'cctvLive'
  | 'cctvJobs'
  | 'utilityBills'
  | 'telecomBills'
  | 'expenses'
  | 'bankLedger'
  | 'receivables'
  | 'returns'
  | 'purchaseOrders'
  | 'costCompare'
  | 'reports'
  | 'ownerPanel';

interface SidebarProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  isOpen: boolean;
  onClose: () => void;
  activeLanguage: LanguageCode;
  currentUser: User;
  lowStockCount: number;
  activeRepairsCount: number;
  activeFieldJobsCount: number;
  doorLocked: boolean;
  pendingInvoicesCount: number;
  onOpenAIModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isOpen,
  onClose,
  activeLanguage,
  currentUser,
  lowStockCount,
  activeRepairsCount,
  activeFieldJobsCount,
  doorLocked,
  pendingInvoicesCount,
  onOpenAIModal,
}) => {
  const t = TRANSLATIONS[activeLanguage] || TRANSLATIONS.en;

  const navItems: {
    id: NavigationTab;
    label: string;
    icon: React.ReactNode;
    badge?: string | number;
    badgeColor?: string;
    requiresPermission?: keyof User['permissions'];
    category?: string;
  }[] = [
    {
      id: 'dashboard',
      label: t.dashboard,
      icon: <LayoutDashboard className="w-4 h-4" />,
      category: 'Overview',
    },
    {
      id: 'pos',
      label: t.pos,
      icon: <ShoppingCart className="w-4 h-4 text-emerald-400" />,
      category: 'Sales & Inventory',
    },
    {
      id: 'inventory',
      label: t.inventory,
      icon: <Boxes className="w-4 h-4 text-blue-400" />,
      badge: lowStockCount > 0 ? lowStockCount : undefined,
      badgeColor: 'bg-rose-500/80 text-white',
      category: 'Sales & Inventory',
    },
    {
      id: 'customers',
      label: t.customers || 'Customer Directory & Credit',
      icon: <Users className="w-4 h-4 text-emerald-400" />,
      category: 'Sales & Inventory',
    },
    {
      id: 'branchTransfer',
      label: t.branchTransfer || 'Branch Stock Transfers',
      icon: <ArrowRightLeft className="w-4 h-4 text-cyan-400" />,
      category: 'Sales & Inventory',
    },
    {
      id: 'returns',
      label: t.returns,
      icon: <RotateCcw className="w-4 h-4 text-amber-400" />,
      category: 'Sales & Inventory',
    },
    {
      id: 'repairs',
      label: t.repairs,
      icon: <Wrench className="w-4 h-4 text-orange-400" />,
      badge: activeRepairsCount > 0 ? activeRepairsCount : undefined,
      badgeColor: 'bg-orange-500/80 text-white',
      category: 'Services & Security',
    },
    {
      id: 'pendingBottlenecks',
      label: t.pendingBottlenecks || 'Owner Services Tracker',
      icon: <ShieldAlert className="w-4 h-4 text-rose-400" />,
      badge: 'DELAYS',
      badgeColor: 'bg-rose-500/20 text-rose-400 border border-rose-500/30',
      category: 'Services & Security',
    },
    {
      id: 'cctvLive',
      label: t.cctvLive,
      icon: <Cctv className="w-4 h-4 text-cyan-400" />,
      badge: doorLocked ? 'LOCKED' : 'UNLOCKED',
      badgeColor: doorLocked ? 'bg-emerald-500/30 text-emerald-300' : 'bg-amber-500/30 text-amber-300',
      requiresPermission: 'accessCCTV',
      category: 'Services & Security',
    },
    {
      id: 'cctvJobs',
      label: t.cctvJobs,
      icon: <Truck className="w-4 h-4 text-purple-400" />,
      badge: activeFieldJobsCount > 0 ? activeFieldJobsCount : undefined,
      badgeColor: 'bg-purple-500/80 text-white',
      category: 'Services & Security',
    },
    {
      id: 'utilityBills',
      label: t.utilityBills,
      icon: <Zap className="w-4 h-4 text-yellow-400" />,
      category: 'Oman Bill Payments',
    },
    {
      id: 'telecomBills',
      label: t.telecomBills,
      icon: <PhoneCall className="w-4 h-4 text-teal-400" />,
      category: 'Oman Bill Payments',
    },
    {
      id: 'costCompare',
      label: t.costCompare,
      icon: <Scale className="w-4 h-4 text-indigo-400" />,
      category: 'Oman Bill Payments',
    },
    {
      id: 'expenses',
      label: t.expenses,
      icon: <Receipt className="w-4 h-4 text-rose-400" />,
      category: 'Finance & Treasury',
    },
    {
      id: 'bankLedger',
      label: t.bankLedger,
      icon: <Landmark className="w-4 h-4 text-blue-400" />,
      requiresPermission: 'viewFinancialLedgers',
      category: 'Finance & Treasury',
    },
    {
      id: 'receivables',
      label: t.receivables,
      icon: <FileText className="w-4 h-4 text-indigo-400" />,
      badge: pendingInvoicesCount > 0 ? pendingInvoicesCount : undefined,
      badgeColor: 'bg-amber-500/80 text-slate-950 font-bold',
      category: 'Finance & Treasury',
    },
    {
      id: 'purchaseOrders',
      label: t.purchaseOrders,
      icon: <PackageCheck className="w-4 h-4 text-emerald-400" />,
      category: 'Finance & Treasury',
    },
    {
      id: 'reports',
      label: t.reports,
      icon: <CalendarRange className="w-4 h-4 text-sky-400" />,
      requiresPermission: 'viewFinancialLedgers',
      category: 'Intelligence & Management',
    },
    {
      id: 'ownerPanel',
      label: t.ownerPanel,
      icon: <Crown className="w-4 h-4 text-amber-400" />,
      category: 'Intelligence & Management',
    },
  ];

  // Group by category
  const categories = Array.from(new Set(navItems.map((item) => item.category)));

  return (
    <>
      {/* Backdrop for mobile */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-950/70 backdrop-blur-sm lg:hidden transition-opacity"
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed top-[53px] bottom-0 left-0 z-40 w-64 bg-slate-900 border-r border-slate-800 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-5 scrollbar-thin scrollbar-thumb-slate-800">
          {categories.map((category) => {
            const items = navItems.filter((i) => i.category === category);
            return (
              <div key={category} className="space-y-1">
                <div className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  {category}
                </div>
                {items.map((item) => {
                  // Check permission
                  if (item.requiresPermission && !currentUser.permissions[item.requiresPermission]) {
                    return null;
                  }

                  const isActive = currentTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onSelectTab(item.id);
                        if (window.innerWidth < 1024) onClose();
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all group ${
                        isActive
                          ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                          : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <span className={isActive ? 'text-slate-950' : ''}>{item.icon}</span>
                        <span className="truncate">{item.label}</span>
                      </div>

                      {item.badge !== undefined && (
                        <span
                          className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
                            isActive
                              ? 'bg-slate-950 text-amber-300'
                              : item.badgeColor || 'bg-slate-700 text-slate-200'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            );
          })}
        </div>

        {/* Gemini AI Floating Promotion Bar */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/40">
          <button
            onClick={() => {
              onOpenAIModal();
              if (window.innerWidth < 1024) onClose();
            }}
            className="w-full p-2.5 rounded-xl bg-gradient-to-r from-purple-900/40 to-indigo-900/40 border border-purple-500/30 hover:border-purple-500/60 transition group text-left cursor-pointer"
          >
            <div className="flex items-center gap-2 text-purple-300 font-bold text-xs mb-1">
              <Sparkles className="w-4 h-4 text-purple-400 group-hover:scale-110 transition" />
              <span>Gemini 3.8 Flash AI</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-tight">
              One-click Oman VAT audit, cashflow forecast & stock anomaly analysis.
            </p>
          </button>

          {/* User info snippet */}
          <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-800/60 text-[10px] text-slate-500">
            <span className="truncate">Logged in as {currentUser.name.split(' ')[0]}</span>
            <span className="capitalize text-amber-400 font-medium">[{currentUser.role}]</span>
          </div>
        </div>
      </aside>
    </>
  );
};
