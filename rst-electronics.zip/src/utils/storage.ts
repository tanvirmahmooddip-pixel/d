import {
  BankAccount,
  BranchStockTransfer,
  CashInHandReconciliation,
  CCTVCamera,
  CCTVFieldJob,
  CurrencyCode,
  ExpenseRecord,
  LanguageCode,
  OfflineQueueItem,
  PendingServiceWork,
  Product,
  ProductCategory,
  ProductReturn,
  PurchaseOrder,
  RepairTicket,
  SaleTransaction,
  SmartDoor,
  StoreLocation,
  TelecomBillPayment,
  User,
  UtilityBillPayment,
  Customer,
} from '../types';
import {
  INITIAL_BANK_ACCOUNTS,
  INITIAL_BRANCHES,
  INITIAL_CATEGORIES,
  INITIAL_CCTV_CAMERAS,
  INITIAL_CUSTOMERS,
  INITIAL_EXPENSES,
  INITIAL_FIELD_JOBS,
  INITIAL_PRODUCTS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_REPAIR_TICKETS,
  INITIAL_RETURNS,
  INITIAL_SALES,
  INITIAL_SMART_DOOR,
  INITIAL_TELECOM_BILLS,
  INITIAL_USERS,
  INITIAL_UTILITY_BILLS,
} from '../data/initialData';

export interface CompanyConfig {
  companyName: string;
  companyNameAr: string;
  crNumber: string;
  vatNumber: string;
  phone: string;
  email: string;
  address: string;
  invoiceFooterNote: string;
  invoiceFooterNoteAr: string;
}

export const INITIAL_BRANCH_TRANSFERS: BranchStockTransfer[] = [
  {
    id: 'tr-01',
    transferNumber: 'TR-OM-2026-081',
    date: '2026-10-06',
    sourceBranchId: 'branch-ruwi',
    sourceBranchName: 'Ruwi High Street (HQ)',
    targetBranchId: 'branch-khoudh',
    targetBranchName: 'Al Khoudh Commercial',
    items: [
      {
        productId: 'prod-iphone16pro-256',
        productName: 'Apple iPhone 16 Pro 256GB - Desert Titanium',
        sku: 'APL-IP16P-256-DES',
        barcode: '195949102938',
        quantity: 2,
      },
      {
        productId: 'prod-anker-65w-gan',
        productName: 'Anker 735 GaNPrime 65W Fast Charger',
        sku: 'ANK-735-65W-UK',
        barcode: '194644083719',
        quantity: 5,
      },
    ],
    status: 'in_transit',
    transferredBy: 'Rabiul & Big Brother (Owners)',
    notes: 'Inter-branch stock rebalance for evening customer reservations.',
  },
];

export const INITIAL_PENDING_SERVICES: PendingServiceWork[] = [
  {
    id: 'ps-01',
    serviceType: 'mobile_repair',
    referenceCode: 'REP-2026-083',
    customerName: 'Bader Al-Qasmi',
    customerPhone: '+968 9456 1234',
    deviceOrSite: 'Xiaomi Redmi Note 12 (Water damaged at Seeb)',
    assignedPerson: 'Salim Al-Maamari (Tech)',
    branchId: 'branch-ruwi',
    daysPending: 3,
    reasonCategory: 'motherboard_microsoldering',
    pendingDetailsReason: 'Main PMIC power IC burned under ultrasonic cleaning; waiting for replacement chip shipment from Dubai.',
    supervisorActionNotes: 'Owner approved DHL express courier for micro-soldering IC chip.',
    priority: 'high',
    status: 'pending',
    createdAt: '2026-10-03',
  },
  {
    id: 'ps-02',
    serviceType: 'cctv_field_job',
    referenceCode: 'CCTV-JOB-102',
    customerName: 'Al-Nahda Trading Hypermarket',
    customerPhone: '+968 9511 2233',
    deviceOrSite: 'Commercial 16-Cam IP NVR System (Barka)',
    assignedPerson: 'Rashid Al-Kindi (Field Tech)',
    branchId: 'branch-ruwi',
    daysPending: 2,
    reasonCategory: 'weather_site_access',
    pendingDetailsReason: 'Customer building exterior scaffold permit delayed by Barka Municipality; waiting for high-ceiling access approval.',
    supervisorActionNotes: 'Manager contacted client facility director to expedite municipal gate pass.',
    priority: 'normal',
    status: 'pending',
    createdAt: '2026-10-04',
  },
  {
    id: 'ps-03',
    serviceType: 'mobile_repair',
    referenceCode: 'REP-2026-079',
    customerName: 'Tariq Al-Fazari',
    customerPhone: '+968 9234 9900',
    deviceOrSite: 'Samsung Galaxy S24 Ultra (No display after drop)',
    assignedPerson: 'Salim Al-Maamari (Tech)',
    branchId: 'branch-ruwi',
    daysPending: 4,
    reasonCategory: 'waiting_customer_approval',
    pendingDetailsReason: 'Screen replacement quote OMR 85.000 sent via SMS; customer phone switched off / not answering WhatsApp calls.',
    supervisorActionNotes: 'Customer contacted on alternate office landline; requested 24 hours to confirm.',
    priority: 'urgent',
    status: 'pending',
    createdAt: '2026-10-02',
  },
];

export interface AppState {
  branches: StoreLocation[];
  activeBranchId: string;
  users: User[];
  activeUserId: string;
  categories: ProductCategory[];
  products: Product[];
  sales: SaleTransaction[];
  repairTickets: RepairTicket[];
  cctvCameras: CCTVCamera[];
  smartDoor: SmartDoor;
  fieldJobs: CCTVFieldJob[];
  utilityBills: UtilityBillPayment[];
  telecomBills: TelecomBillPayment[];
  expenses: ExpenseRecord[];
  bankAccounts: BankAccount[];
  purchaseOrders: PurchaseOrder[];
  returns: ProductReturn[];
  reconciliations: CashInHandReconciliation[];
  branchTransfers: BranchStockTransfer[];
  pendingServices: PendingServiceWork[];
  offlineQueue: OfflineQueueItem[];
  customers: Customer[];
  activeCurrency: CurrencyCode;
  activeLanguage: LanguageCode;
  companyConfig: CompanyConfig;
}

const STORAGE_KEY = 'al_rabil_erp_v2_data';

const DEFAULT_COMPANY_CONFIG: CompanyConfig = {
  companyName: 'Al-Rabiul & Big Brother Mobiles & Smart Security LLC',
  companyNameAr: 'شركة ربيع والأخ الأكبر للهواتف والأمان الذكي ش.م.م',
  crNumber: 'CR 1394821',
  vatNumber: 'OM1100239102',
  phone: '+968 2478 9120',
  email: 'info@alrabiul-oman.com',
  address: 'Ruwi Commercial High Street, Ruwi, Sultanate of Oman',
  invoiceFooterNote: 'Goods once sold can be exchanged within 7 days with original invoice in sellable condition. 12-month manufacturer warranty on official mobile units.',
  invoiceFooterNoteAr: 'البضاعة المباعة يمكن استبدالها خلال 7 أيام مع الفاتورة الأصلية بحالتها الأصلية. ضمان رسمي لمدة 12 شهر على الهواتف المعتمدة.',
};

export function getInitialState(): AppState {
  return {
    branches: INITIAL_BRANCHES,
    activeBranchId: INITIAL_BRANCHES[0].id,
    users: INITIAL_USERS,
    activeUserId: INITIAL_USERS[0].id, // Rabiul (Owner)
    categories: INITIAL_CATEGORIES,
    products: INITIAL_PRODUCTS,
    sales: INITIAL_SALES,
    repairTickets: INITIAL_REPAIR_TICKETS,
    cctvCameras: INITIAL_CCTV_CAMERAS,
    smartDoor: INITIAL_SMART_DOOR,
    fieldJobs: INITIAL_FIELD_JOBS,
    utilityBills: INITIAL_UTILITY_BILLS,
    telecomBills: INITIAL_TELECOM_BILLS,
    expenses: INITIAL_EXPENSES,
    bankAccounts: INITIAL_BANK_ACCOUNTS,
    purchaseOrders: INITIAL_PURCHASE_ORDERS,
    returns: INITIAL_RETURNS,
    reconciliations: [],
    branchTransfers: INITIAL_BRANCH_TRANSFERS,
    pendingServices: INITIAL_PENDING_SERVICES,
    offlineQueue: [],
    customers: INITIAL_CUSTOMERS,
    activeCurrency: 'OMR',
    activeLanguage: 'en',
    companyConfig: DEFAULT_COMPANY_CONFIG,
  };
}

export function loadAppState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const init = getInitialState();
      saveAppState(init);
      return init;
    }
    const parsed = JSON.parse(raw);

    // Ensure Rabiul and Big Brother owners are always present
    const existingUsers = Array.isArray(parsed.users) ? parsed.users : INITIAL_USERS;
    const hasRabiul = existingUsers.some(
      (u: User) => u.name.toLowerCase().includes('rabiul') || u.id === 'user-rabiul-owner'
    );
    const hasBigBrother = existingUsers.some(
      (u: User) => u.name.toLowerCase().includes('big brother') || u.id === 'user-bigbrother-owner'
    );

    let updatedUsers = existingUsers;
    if (!hasRabiul || !hasBigBrother) {
      // Replace old placeholder or insert Rabiul and Big Brother
      const nonOwners = existingUsers.filter((u: User) => u.role !== 'owner');
      updatedUsers = [INITIAL_USERS[0], INITIAL_USERS[1], ...nonOwners];
    }

    const state: AppState = {
      ...getInitialState(),
      ...parsed,
      users: updatedUsers,
      activeUserId: updatedUsers[0].id,
      customers: Array.isArray(parsed.customers) && parsed.customers.length > 0 ? parsed.customers : INITIAL_CUSTOMERS,
      companyConfig: {
        ...DEFAULT_COMPANY_CONFIG,
        ...(parsed.companyConfig || {}),
        companyName: parsed.companyConfig?.companyName?.includes('Rabiul')
          ? parsed.companyConfig.companyName
          : DEFAULT_COMPANY_CONFIG.companyName,
        companyNameAr: parsed.companyConfig?.companyNameAr?.includes('ربيع')
          ? parsed.companyConfig.companyNameAr
          : DEFAULT_COMPANY_CONFIG.companyNameAr,
      },
    };

    saveAppState(state);
    return state;
  } catch (e) {
    console.error('Failed to load state from localStorage:', e);
    return getInitialState();
  }
}

export function saveAppState(state: AppState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save state to localStorage:', e);
  }
}
